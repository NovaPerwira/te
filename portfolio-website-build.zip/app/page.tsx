'use client'

import { useState } from 'react'
import Link from 'next/link'
import Image from 'next/image'
import { Menu, X, ArrowRight } from 'lucide-react'

export default function Home() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  const services = [
    {
      number: '01',
      title: 'Branding & Marketing',
      description: 'Strategic visual identity that builds trust and drives engagement across all platforms.',
      items: [
        'Brand Strategy and Messaging',
        'Logo Design',
        'Visual Identity',
        'Brand Guidelines & Frameworks',
        'Marketing Materials',
        'Motion Design'
      ]
    },
    {
      number: '02',
      title: 'Web Design',
      description: 'Modern, responsive interfaces built for conversion and user engagement.',
      items: [
        'UX/UI Design',
        'Responsive Web Design',
        'Design Systems',
        'Prototyping & Wireframes',
        'User Research',
        'Accessibility Audit'
      ]
    },
    {
      number: '03',
      title: 'Development',
      description: 'Full-stack web solutions with clean code, performance optimization, and scalability.',
      items: [
        'Frontend Development',
        'Full-Stack Applications',
        'API Integration',
        'Database Design',
        'Performance Optimization',
        'Deployment & Maintenance'
      ]
    }
  ]

  const projects = [
    {
      title: 'E-Commerce Platform Redesign',
      category: 'Design, Development',
      description: 'Complete platform overhaul resulting in 40% increase in conversion rate'
    },
    {
      title: 'SaaS Dashboard Development',
      category: 'Development, Design',
      description: 'Real-time analytics dashboard with custom data visualization components'
    },
    {
      title: 'Brand Identity System',
      category: 'Branding, Design',
      description: 'Comprehensive brand guidelines and design system for growing startup'
    },
    {
      title: 'Mobile App Design',
      category: 'Design, Development',
      description: 'iOS & Android native application with seamless user experience'
    }
  ]

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-background/95 backdrop-blur-sm z-50 border-b border-border">
        <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
          <Link href="/" className="text-lg font-semibold">
            Alex Graham
          </Link>
          
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden p-2 hover:bg-secondary rounded-lg transition-colors"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>

          <div className={`${
            isMenuOpen ? 'flex' : 'hidden'
          } md:flex flex-col md:flex-row gap-8 absolute md:relative top-16 md:top-0 left-0 md:left-auto right-0 bg-background md:bg-transparent p-6 md:p-0 border-b md:border-0 border-border`}>
            <Link href="#projects" className="hover:text-accent transition-colors">
              Projects
            </Link>
            <Link href="#services" className="hover:text-accent transition-colors">
              Services
            </Link>
            <Link href="#about" className="hover:text-accent transition-colors">
              About
            </Link>
            <Link href="#contact" className="hover:text-accent transition-colors">
              Contact
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-6">
        <div className="max-w-7xl mx-auto grid md:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="space-y-8">
            <div>
              <h1 className="text-5xl md:text-6xl font-bold mb-4 leading-tight">
                Alex Graham
              </h1>
              <p className="text-xl text-muted-foreground">
                Designer & Web Engineer
              </p>
            </div>

            <p className="text-lg leading-relaxed max-w-lg">
              I'm a versatile designer who partners with founders to turn ideas into real products. I focus on clear interfaces, sharp decisions, and fast execution.
            </p>

            <p className="text-base text-muted-foreground leading-relaxed max-w-lg">
              Bringing your vision to life quickly and efficiently—whether it's branding, apps, or websites—I've got it covered. Delivering smooth and effective solutions from start to finish.
            </p>

            <button className="inline-flex items-center gap-2 px-6 py-3 border border-foreground hover:bg-foreground hover:text-background transition-colors">
              See my Work
              <ArrowRight size={18} />
            </button>
          </div>

          {/* Right Image */}
          <div className="relative h-96 md:h-full md:min-h-96">
            <Image
              src="/hero-portrait.jpg"
              alt="Alex Graham - Portfolio"
              fill
              className="object-cover rounded-lg"
              priority
            />
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 px-6 bg-secondary/30">
        <div className="max-w-7xl mx-auto">
          <div className="mb-16">
            <h2 className="text-4xl font-bold mb-4">Services</h2>
            <p className="text-lg text-muted-foreground max-w-2xl">
              Comprehensive design and development services tailored to your business needs.
            </p>
          </div>

          <div className="space-y-16">
            {services.map((service, index) => (
              <div key={index} className="border-t border-border pt-12 first:border-t-0 first:pt-0">
                <div className="grid md:grid-cols-3 gap-12">
                  <div>
                    <p className="text-5xl font-bold text-muted-foreground mb-4">
                      {service.number}
                    </p>
                    <h3 className="text-2xl font-bold">
                      {service.title}
                    </h3>
                  </div>

                  <div>
                    <p className="text-foreground leading-relaxed">
                      {service.description}
                    </p>
                  </div>

                  <div className="space-y-2">
                    {service.items.map((item, i) => (
                      <p key={i} className="text-muted-foreground text-sm">
                        {item}
                      </p>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="py-20 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="mb-16">
            <h2 className="text-4xl font-bold mb-4">Featured Projects</h2>
            <p className="text-lg text-muted-foreground">
              A selection of recent work across design and development.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {projects.map((project, index) => (
              <div
                key={index}
                className="group border border-border rounded-lg p-8 hover:bg-secondary/50 transition-colors cursor-pointer"
              >
                <div className="aspect-video bg-muted rounded-lg mb-6" />
                <p className="text-sm text-accent font-semibold mb-3">
                  {project.category}
                </p>
                <h3 className="text-2xl font-bold mb-3 group-hover:text-accent transition-colors">
                  {project.title}
                </h3>
                <p className="text-muted-foreground">
                  {project.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 px-6 bg-secondary/30">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-4xl font-bold mb-12">About Me</h2>
          
          <div className="space-y-8 text-lg leading-relaxed text-muted-foreground">
            <p>
              With over a decade of experience bridging design and development, I've had the opportunity to work with startups, agencies, and corporations. My background spans visual identity, digital products, and full-stack engineering.
            </p>

            <p>
              What drives me is the intersection of beautiful design and clean code. I believe that the best products are those that look great AND work perfectly. Every pixel, every interaction, every line of code matters.
            </p>

            <p>
              When I'm not designing or coding, you'll find me exploring new design trends, contributing to open-source projects, or mentoring junior designers and developers.
            </p>
          </div>

          <div className="mt-16 pt-16 border-t border-border">
            <h3 className="text-xl font-semibold mb-6">Skills & Tools</h3>
            <div className="grid md:grid-cols-3 gap-8">
              <div>
                <p className="font-semibold mb-3">Design</p>
                <p className="text-sm text-muted-foreground">Figma, Adobe CC, Sketch, Prototyping</p>
              </div>
              <div>
                <p className="font-semibold mb-3">Development</p>
                <p className="text-sm text-muted-foreground">React, Next.js, TypeScript, Tailwind CSS</p>
              </div>
              <div>
                <p className="font-semibold mb-3">Other</p>
                <p className="text-sm text-muted-foreground">Git, Databases, APIs, Cloud Deployment</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold mb-6">Let's Work Together</h2>
          <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
            Have a project in mind? I'd love to hear about it. Let's create something amazing.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="px-8 py-3 bg-accent text-accent-foreground font-semibold rounded hover:opacity-90 transition-opacity">
              Get in Touch
            </button>
            <button className="px-8 py-3 border border-foreground hover:bg-foreground hover:text-background transition-colors font-semibold rounded">
              View Resume
            </button>
          </div>

          <div className="mt-16 pt-16 border-t border-border flex justify-center gap-8">
            <Link href="#" className="text-muted-foreground hover:text-foreground transition-colors">
              LinkedIn
            </Link>
            <Link href="#" className="text-muted-foreground hover:text-foreground transition-colors">
              Twitter
            </Link>
            <Link href="#" className="text-muted-foreground hover:text-foreground transition-colors">
              GitHub
            </Link>
            <Link href="#" className="text-muted-foreground hover:text-foreground transition-colors">
              Email
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-primary text-primary-foreground py-8 px-6">
        <div className="max-w-7xl mx-auto text-center text-sm">
          <p>© 2024 Alex Graham. All rights reserved.</p>
        </div>
      </footer>
    </div>
  )
}
